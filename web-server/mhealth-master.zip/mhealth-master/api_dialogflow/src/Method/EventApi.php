<?php

namespace DialogFlow\Method;

use DialogFlow\Client;
use DialogFlow\ResponseHandler;
use GuzzleHttp\Promise\PromiseInterface;
use Psr\Http\Message\ResponseInterface;

/**
 * Class EventApi
 *
 * @package DialogFlow\Method
 */
class EventApi
{
    use ResponseHandler;

    /**
     * @var Client
     */
    private $client;

    /**
     * Query constructor.
     *
     * @param Client $client
     */
    public function __construct(Client $client)
    {
        $this->client = $client;
    }

    /**
     * @param string $event
     * @param array $extraParams
     *
     * @return mixed
     */
    public function extractMeaning($event, $extraParams = [])
    {
        $event = array_merge($extraParams, [
            'lang' => $this->client->getApiLanguage(),
            'event' => $event,
            'query' => ''
        ]);

        // uri is /query
        $response = $this->client->post('query', $event);

        return $this->decodeResponse($response);
    }

    /**
     * @param $event
     * @param array $extraParams
     *
     * @return PromiseInterface
     */
    public function extractMeaningAsync($event, $extraParams = [])
    {
        $event = array_merge($extraParams, [
            'lang' => $this->client->getApiLanguage(),
            'event' => $event,
            'query' => ''
        ]);

        // uri is /query
        return $this->client->postAsync('query', $event)->then([$this, 'decodeResponse']);
    }
}